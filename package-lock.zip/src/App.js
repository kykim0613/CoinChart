const { default: Router } = require("./Router")

const App = () => {
    return (
        <>
        <Router />
        </>
    )
}

export default App;