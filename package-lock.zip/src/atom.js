import styled from "styled-components";

export const Market = styled.h1`
    width: 100px;
    height: 100px;
    margin: 0 auto;
`

export const Axis = () => {
    
}